;/*FB_PKG_DELIM*/

__d("CAAWebWaterfallIdSingleton",["uuidv4"],(function(a,b,c,d,e,f,g){"use strict";a=function(){function a(){this.$1=c("uuidv4")()}var b=a.prototype;b.getWaterfallID=function(){return this.$1};b.setWaterfallID=function(a){this.$1=a};return a}();b=new a();g["default"]=b}),98);