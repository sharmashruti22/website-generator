;/*FB_PKG_DELIM*/

__d("VultureJSSampleRatesLoader",["VultureJSSampleRates","asyncToGeneratorRuntime"],(function(a,b,c,d,e,f,g){"use strict";function a(){return h.apply(this,arguments)}function h(){h=b("asyncToGeneratorRuntime").asyncToGenerator(function*(){return c("VultureJSSampleRates").sample_rates});return h.apply(this,arguments)}g.loadSampleRates=a}),98);